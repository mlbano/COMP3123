import logo from './logo.svg';
import './App.css';

function App() {
  return (
    <div className="App">
      <header className="App-header">
        <img src={logo} className="App-logo" alt="logo" />
        <p>
          <h2>Welcome to Fullstack Development - I</h2>
          <h3>React JS Programming Week09 Lab exercise</h3>
          <h4>101355992</h4>
          <h5>Milanie Bano</h5>
          <h6>George Brown College, Toronto</h6>
        </p>
      </header>
    </div>
  );
}

export default App;
